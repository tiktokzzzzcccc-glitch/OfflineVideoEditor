Offline Video Editor — Android Studio Project

Final feature set
- Select a local video
- Speed 0.5x to 4.0x (1.3x included)
- Dreamy Mood filter
- Story Filter
- Black & White filter
- 720p HD export
- 1080p Full HD export
- H.264 video + AAC audio MP4 export
- Saves to Gallery: Movies/OfflineVideoEditor
- Offline processing after the app is installed
- Streaming/file-based processing: the whole video is not loaded into RAM

Important resolution behavior
- The selected 720p/1080p value is applied as a target HEIGHT while keeping the original aspect ratio.
- A source smaller than the selected target is not artificially upscaled.

PC setup
1. Install Android Studio on the PC.
2. Open this folder as an existing Android Studio project.
3. Let Android Studio sync the Gradle project. The first setup/build normally needs internet to download Android Gradle Plugin and AndroidX/Media3 dependencies.
4. Build > Build APK(s).
5. Copy/install the APK on the Android phone.
6. After installation, video editing/export is local and does not require an internet connection.

Notes
- Export time depends on video length, resolution, phone/PC hardware and source codec.
- Long videos are processed as streams/files rather than loading the entire video into memory, reducing RAM pressure, but no software can guarantee that every very long/large export will never fail.
