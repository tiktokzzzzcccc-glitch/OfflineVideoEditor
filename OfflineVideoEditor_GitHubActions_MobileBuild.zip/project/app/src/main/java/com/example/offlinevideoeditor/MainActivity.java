package com.example.offlinevideoeditor;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.*;

import androidx.annotation.Nullable;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.effect.Contrast;
import androidx.media3.effect.HslAdjustment;
import androidx.media3.effect.RgbMatrix;
import androidx.media3.effect.ScaleAndRotateTransformation;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.Effects;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.Transformer;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@UnstableApi
public class MainActivity extends Activity {
    private VideoView preview;
    private TextView speedLabel, status;
    private Uri input;
    private float speedValue = 1.0f;
    private boolean exporting = false;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18, 12, 18, 12);

        TextView title = new TextView(this);
        title.setText("Offline Video Editor");
        title.setTextSize(24);
        root.addView(title);

        Button pick = new Button(this);
        pick.setText("Select Video");
        root.addView(pick);

        preview = new VideoView(this);
        preview.setBackgroundColor(0xFF000000);
        root.addView(preview, new LinearLayout.LayoutParams(-1, 0, 1));

        speedLabel = new TextView(this);
        speedLabel.setText("Speed: 1.0×");
        root.addView(speedLabel);

        SeekBar speed = new SeekBar(this);
        speed.setMax(70); // 0.5x to 4.0x in 0.05x steps
        speed.setProgress(10);
        root.addView(speed);
        speed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                speedValue = 0.5f + (p / 20f);
                speedLabel.setText(String.format("Speed: %.1f×", speedValue));
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });

        root.addView(label("Filter"));
        Spinner filter = spinner(new String[]{"None", "Dreamy Mood", "Story Filter", "Black & White"});
        root.addView(filter);

        root.addView(label("Output Resolution"));
        Spinner resolution = spinner(new String[]{"720p HD", "1080p Full HD"});
        root.addView(resolution);

        Button save = new Button(this);
        save.setText("SAVE VIDEO");
        root.addView(save);

        status = new TextView(this);
        status.setText("Ready • Offline processing");
        root.addView(status);

        pick.setOnClickListener(v -> choose());
        save.setOnClickListener(v -> export((String) filter.getSelectedItem(), (String) resolution.getSelectedItem()));

        preview.setOnPreparedListener(mp -> {
            if (android.os.Build.VERSION.SDK_INT >= 23) {
                mp.setPlaybackParams(mp.getPlaybackParams().setSpeed(speedValue));
            }
            mp.start();
        });

        setContentView(root);
    }


    private TextView label(String x) {
        TextView t = new TextView(this);
        t.setText(x); t.setTextSize(16); t.setPadding(0, 8, 0, 2);
        return t;
    }

    private Spinner spinner(String[] values) {
        Spinner s = new Spinner(this);
        s.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, values));
        return s;
    }

    private void choose() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("video/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, 10);
    }

    @Override protected void onActivityResult(int r, int c, @Nullable Intent d) {
        super.onActivityResult(r, c, d);
        if (r == 10 && c == RESULT_OK && d != null && d.getData() != null) {
            input = d.getData();
            try { getContentResolver().takePersistableUriPermission(input, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
            preview.setVideoURI(input);
            status.setText("Video selected");
        }
    }

    private void export(String filter, String resolution) {
        if (input == null) { Toast.makeText(this, "Pehle video select karein", Toast.LENGTH_SHORT).show(); return; }
        if (exporting) return;
        exporting = true;
        File out = new File(getExternalFilesDir(null), "Edited_" + System.currentTimeMillis() + ".mp4");
        try {
            MediaItem item = MediaItem.fromUri(input);
            EditedMediaItem.Builder eb = new EditedMediaItem.Builder(item).setSpeed(speedValue);
            List<androidx.media3.effect.GlEffect> vfx = new ArrayList<>();
            if ("Black & White".equals(filter)) {
                vfx.add(RgbMatrix.createGrayscaleMatrix());
            } else if ("Dreamy Mood".equals(filter)) {
                vfx.add(new Contrast(0.90f));
                vfx.add(new HslAdjustment.Builder().setSaturation(0.85f).setLightness(0.08f).build());
            } else if ("Story Filter".equals(filter)) {
                vfx.add(new Contrast(1.08f));
                vfx.add(new HslAdjustment.Builder().setSaturation(1.08f).setLightness(0.02f).build());
            }

            // Scale the video to the selected target height while preserving aspect ratio.
            // Media3 processes the stream instead of loading the whole video into RAM.
            int targetHeight = "1080p Full HD".equals(resolution) ? 1080 : 720;
            float scale = calculateScaleToHeight(input, targetHeight);
            vfx.add(new ScaleAndRotateTransformation.Builder().setScale(scale, scale).build());

            eb.setEffects(new Effects(Collections.emptyList(), vfx));
            EditedMediaItem edited = eb.build();

            Transformer transformer = new Transformer.Builder(this)
                    .setVideoMimeType(MimeTypes.VIDEO_H264)
                    .setAudioMimeType(MimeTypes.AUDIO_AAC)
                    .addListener(new Transformer.Listener() {
                        @Override public void onCompleted(Composition composition, ExportResult result) {
                            runOnUiThread(() -> {
                                try {
                                    Uri saved = saveToGallery(out);
                                    status.setText("Saved to Movies/OfflineVideoEditor");
                                    Toast.makeText(MainActivity.this, "Video saved", Toast.LENGTH_LONG).show();
                                    out.delete();
                                } catch (Exception e) {
                                    status.setText("Saved file, but Gallery copy failed: " + e.getMessage());
                                }
                                exporting = false;
                            });
                        }
                        @Override public void onError(Composition composition, ExportResult result, androidx.media3.transformer.ExportException e) {
                            runOnUiThread(() -> {
                                status.setText("Export error: " + e.getMessage());
                                exporting = false;
                                out.delete();
                            });
                        }
                    }).build();
            status.setText("Exporting offline…");
            transformer.start(edited, out.getAbsolutePath());
        } catch (Exception e) {
            exporting = false;
            status.setText("Export error: " + e.getMessage());
        }
    }

    private float calculateScaleToHeight(Uri uri, int targetHeight) throws Exception {
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(this, uri);
            String w = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH);
            String h = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT);
            if (w == null || h == null) return 1.0f;
            int width = Integer.parseInt(w);
            int height = Integer.parseInt(h);
            String rotation = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION);
            if (rotation != null) {
                int r = Integer.parseInt(rotation);
                if (r == 90 || r == 270) { int t = width; width = height; height = t; }
            }
            if (height <= 0) return 1.0f;
            // Do not upscale a smaller source.
            return Math.min(1.0f, targetHeight / (float) height);
        } finally {
            retriever.release();
        }
    }

    private Uri saveToGallery(File source) throws Exception {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Video.Media.DISPLAY_NAME, source.getName());
        values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
        values.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/OfflineVideoEditor");
        values.put(MediaStore.Video.Media.IS_PENDING, 1);
        Uri uri = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new Exception("Could not create gallery item");
        try (FileInputStream in = new FileInputStream(source); OutputStream out = getContentResolver().openOutputStream(uri)) {
            if (out == null) throw new Exception("Could not open gallery output");
            byte[] buf = new byte[1024 * 1024];
            int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
        }
        ContentValues done = new ContentValues();
        done.put(MediaStore.Video.Media.IS_PENDING, 0);
        getContentResolver().update(uri, done, null, null);
        return uri;
    }
}
